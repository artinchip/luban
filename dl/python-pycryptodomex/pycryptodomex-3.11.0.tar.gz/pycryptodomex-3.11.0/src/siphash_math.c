/*
   This file is used to workaround a bug in distutils that causes race
   conditions when the same source file is used in multiple extensions.
 */

#include "siphash.c"
