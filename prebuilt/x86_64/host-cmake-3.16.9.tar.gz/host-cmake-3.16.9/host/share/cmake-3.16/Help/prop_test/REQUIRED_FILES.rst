REQUIRED_FILES
--------------

List of files required to run the test.

If set to a list of files, the test will not be run unless all of the
files exist.
