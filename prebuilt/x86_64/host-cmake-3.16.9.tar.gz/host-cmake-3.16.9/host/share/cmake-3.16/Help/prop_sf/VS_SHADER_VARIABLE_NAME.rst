VS_SHADER_VARIABLE_NAME
-----------------------

Set name of variable in header file containing object code of a ``.hlsl``
source file.
