EchoString
----------

A message to be displayed when the target is built.

A message to display on some generators (such as :ref:`Makefile Generators`)
when the target is built.
