<CONFIG>_OUTPUT_NAME
--------------------

Old per-configuration target file base name.
Use :prop_tgt:`OUTPUT_NAME_<CONFIG>` instead.

This is a configuration-specific version of the :prop_tgt:`OUTPUT_NAME`
target property.
