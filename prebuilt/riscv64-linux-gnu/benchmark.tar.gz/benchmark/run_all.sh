#!/bin/sh

TOP_DIR=$PWD

if [ $# -gt 0 ]; then
	if [ -d $1 ]; then
		cd $1
		./run.sh
	else
		echo $1 does not exist!
	fi
	return
fi

for i in `find . -name run.sh`
do
	BENCH_PATH=`dirname $i`
	cd $TOP_DIR/$BENCH_PATH

	echo
	echo Run $i ...
	echo
	./run.sh
done
