#!/bin/sh

COMPILE_TIME=2022-11-18_20-25
BENCH_NAME=`basename $PWD`
TODAY=`date +%Y`
if [ $TODAY -lt 2020 ]; then
	RUN_TIME=$COMPILE_TIME
	echo Suggest to set system time, such as \"set -s 202001012359\"
	echo The name of log file will use compile time: $RUN_TIME
else
	RUN_TIME=`date +%Y-%m-%d_%H-%M`
	echo Current system time: $RUN_TIME
fi
LOG_FILE=${BENCH_NAME}_${RUN_TIME}.log
RESULT_FILE=${BENCH_NAME}_${RUN_TIME}.result

if [ -z $1 ]; then
	LOOPS=5
else
	LOOPS=$1
fi

echo > $LOG_FILE

for dhry in `ls dhry-*`
do
	i=1
	while [ $i -le $LOOPS ]
	do
		echo
		echo $i/$LOOPS. Running $dhry ... 2>&1 | tee temp
		cat temp >> $LOG_FILE
		echo 10000000 | ./$dhry 2>&1 | tee temp
		cat temp >> $LOG_FILE
		i=`expr $i + 1`
	done
done

rm temp
grep -E 'Running dhry|Second:|Score:' $LOG_FILE > $RESULT_FILE
